
import { Slide } from './types';

export const TRAINING_TITLE = "MOVE | Ministério Visão e Propósito (MVP)";
export const HEADLINE = "MOVE";

export const INITIAL_SLIDES: Slide[] = [
  {
    id: 0,
    title: "MOVE",
    type: 'capa',
    subtitle: "Treinamento de Grupos de Crescimento",
    expandableContent: "Ministério Visão e Propósito (MVP)\nPres. Pr. Fábio Alves | Vice Pr. Cleiton Burger\nDesde 2015",
  },
  {
    id: 1,
    title: "Índice",
    type: 'content',
    content: [
      "02 • Para quem é este treinamento",
      "03 • Objetivo e Visão MVP",
      "05 • DNA e Cultura de Serviço",
      "11 • O que é o MOVE (Célula)",
      "18 • Pilares e Prática do Encontro",
      "27 • Liderança e Responsabilidades",
      "31 • Acompanhamento e Multiplicação"
    ],
  },
  {
    id: 2,
    title: "Para quem é este treinamento",
    type: 'checklist',
    checklist: [
      { id: 'pq1', text: "líderes de célula (MOVE)" },
      { id: 'pq2', text: "obreiros e voluntários" },
      { id: 'pq3', text: "anfitriões (casa que recebe)" },
      { id: 'pq4', text: "líderes em treinamento (futuros líderes MOVE)" }
    ]
  },
  {
    id: 3,
    title: "Objetivo do treinamento",
    type: 'checklist',
    checklist: [
      { id: 'obj1', text: "alinhar visão e cultura" },
      { id: 'obj2', text: "formar coração e caráter de liderança" },
      { id: 'obj3', text: "ensinar prática do encontro" },
      { id: 'obj4', text: "garantir cuidado, pastoreio e multiplicação saudável" }
    ]
  },
  {
    id: 4,
    title: "Somos a MVP",
    type: 'content',
    content: [
      "Ministério Visão e Propósito, uma igreja cristã comprometida em amar a Deus, servir pessoas e anunciar Jesus com fé, unidade e excelência. Existimos para estabelecer o Reino de Deus onde Ele nos plantou, levando salvação, restauração e esperança às famílias e à comunidade.",
      "Entendemos que a igreja não se resume a quatro paredes. O templo é o lugar onde nos reunimos para celebrar e adorar juntos, mas a Igreja somos nós, em todos os ambientes onde estivermos: em casa, no trabalho, na escola e na cidade. Por isso, somos uma igreja que ama estar junto, vive em comunhão e caminha como família, expressando Jesus no dia a dia.",
      "Cremos em uma igreja viva e cheia da presença do Espírito Santo, fundamentada na Palavra, que forma crianças, adolescentes, jovens e adultos com identidade, maturidade e propósito. Somos uma família espiritual que busca crescer com direção de Deus, levantando líderes, ativando dons e servindo com alegria para impactar vidas."
    ]
  },
  {
    id: 5,
    title: "DNA MVP",
    type: 'capa',
    subtitle: "O que sustenta tudo o que somos e fazemos é o nosso DNA:\nServir com Excelência.",
  },
  {
    id: 6,
    title: "Servir com Excelência",
    type: 'content',
    subtitle: "É o REINO!",
    content: [
      "Fomos chamados para fazer diferença. O chamado de Jesus, “Ide por todo o mundo”, é uma ordem viva.",
      "Não existimos para nós mesmos, mas para estabelecer o Reino de Deus na terra, levando o Evangelho com verdade, poder e amor."
    ]
  },
  {
    id: 7,
    title: "Nosso compromisso",
    type: 'content',
    content: [
      "Nosso compromisso é maior do que qualquer dor, cansaço ou dificuldade. Não desistimos.",
      "Continuamos, mesmo quando sangra, porque Jesus é suficiente.",
      "Ele é nossa força, nosso alívio e nossa esperança. Parar não é uma opção, porque há vidas que precisam ouvir as boas novas."
    ],
    callout: "Não desistimos. Continuamos porque Ele é suficiente."
  },
  {
    id: 8,
    title: "Como Servimos",
    type: 'content',
    content: [
      "Servir no Reino não é apenas fazer coisas para Deus. É servir pessoas com o coração cheio de Deus.",
      "Nós não servimos apenas para Deus; nós servimos com Deus, como filhos que amam a obra do Pai.",
      "Servir com excelência é viver com Deus e, a partir disso, amar, cuidar e servir o próximo com tudo o que Ele nos confiou."
    ]
  },
  {
    id: 9,
    title: "Missão",
    type: 'checklist',
    subtitle: "O que Queremos Ser",
    checklist: [
      { id: 'mis1', text: "Uma igreja que influencia o lugar onde Deus a estabeleceu" },
      { id: 'mis2', text: "Uma igreja viva, que gera transformação real na comunidade" },
      { id: 'mis3', text: "Um canal de esperança e fortalecimento de famílias" },
      { id: 'mis4', text: "Referência em amor pela Palavra e no ensino" },
      { id: 'mis5', text: "Uma chama que ativa pessoas e ministérios" },
      { id: 'mis6', text: "Um arco que lança flechas inflamadas pelo Espírito de Deus" }
    ]
  },
  {
    id: 10,
    title: "Visão",
    type: 'checklist',
    subtitle: "O que Queremos Ver",
    checklist: [
      { id: 'vis1', text: "Salvação de almas e rendição verdadeira a Jesus" },
      { id: 'vis2', text: "Famílias restauradas e lares curados" },
      { id: 'vis3', text: "Pessoas maduras, vivendo com propósito e cheias de Deus" },
      { id: 'vis4', text: "Dons ativados, líderes levantados e serviço com alegria" },
      { id: 'vis5', text: "Comunidades alcançadas e expansão com direção de Deus" }
    ]
  },
  {
    id: 11,
    title: "O que é o MOVE",
    type: 'content',
    content: [
      "MOVE - Movimento Visão e Expansão",
      "MOVE é uma célula que alguns conhecem como Grupo de Crescimento.",
      "Ele é a igreja estendida para dentro das casas, dentro do dia a dia, dentro das relações mais próximas."
    ]
  },
  {
    id: 12,
    title: "A Prática da Igreja",
    type: 'reflection',
    question: "O culto é onde a igreja se reúne pra celebrar e adorar. O MOVE é onde a igreja acontece na prática.",
  },
  {
    id: 13,
    title: "MOVE é o coração da igreja",
    type: 'content',
    content: [
      "Coração é o lugar que mantém tudo vivo.",
      "Uma igreja pode ter culto forte e mesmo assim ter gente ferida, sem acompanhamento, sem discipulado ou sem amadurecimento."
    ],
    callout: "Sem o MOVE, o cuidado torna-se distante."
  },
  {
    id: 14,
    title: "Equilíbrio",
    type: 'content',
    content: [
      "Isso não é comparação de valor ou importância espiritual.",
      "A igreja primitiva tinha templo e tinha casa.",
      "A força estava no equilíbrio: celebração + vida próxima e compartilhada."
    ]
  },
  {
    id: 15,
    title: "Impacto Real",
    type: 'checklist',
    checklist: [
      { id: 'imp1', text: "queda espiritual vira algo percebido cedo" },
      { id: 'imp2', text: "feridas são tratadas no começo" },
      { id: 'imp3', text: "dúvidas são acolhidas, não escondidas" },
      { id: 'imp4', text: "pecados são confrontados com amor" },
      { id: 'imp5', text: "dons e ministérios são ativados" }
    ]
  },
  {
    id: 16,
    title: "Vamos ser prático?",
    type: 'content',
    subtitle: "O MOVE é",
    content: [
      "uma família espiritual durante a semana",
      "uma extensão da igreja nas casas",
      "discipulado com participação de todos",
      "cuidado, pastoreio, correção e encorajamento",
      "lugar de cura e responsabilidade mútua"
    ]
  },
  {
    id: 17,
    title: "O QUE O MOVE não é",
    type: 'checklist',
    checklist: [
      { id: 'not1', text: "não é um culto" },
      { id: 'not2', text: "apenas um grupo de oração" },
      { id: 'not3', text: "estudo com ouvintes passivos" },
      { id: 'not4', text: "grupo fechado exclusivo (panelinha)" },
      { id: 'not5', text: "reunião para bate-papo" },
      { id: 'not6', text: "comunhão sem objetivo" }
    ]
  },
  {
    id: 18,
    title: "Pilares do MOVE",
    type: 'capa',
    subtitle: "Se um pilar enfraquece, o MOVE vira apenas reunião.\nSe estão firmes, o MOVE cumpre seu objetivo.",
  },
  {
    id: 19,
    title: "Os 7 Pilares",
    type: 'content',
    content: [
      "Comunhão, Cuidado, Evangelização, Ensino, Fortalecimento, Crescimento, Multiplicação."
    ],
  },
  {
    id: 20,
    title: "Comunhão",
    type: 'content',
    content: [
      "Conexão real que cria família e vínculo.",
      "Receber bem e incluir quem chega.",
      "Conversas reais, sem máscara.",
      "Cadeiras em círculo e tempo de mesa."
    ]
  },
  {
    id: 21,
    title: "Cuidado",
    type: 'content',
    content: [
      "Pastoreio de perto com amor e responsabilidade.",
      "Acompanhar ausências e necessidades.",
      "Orar por nomes e situações específicas.",
      "Corrigir com amor quando necessário."
    ]
  },
  {
    id: 22,
    title: "Evangelização",
    type: 'content',
    content: [
      "Alcançar pessoas através de relacionamento.",
      "Manter sempre espaço para visitante.",
      "Orar por pessoas e convidar na semana.",
      "Fazer encontro livre de tempos em tempos."
    ]
  },
  {
    id: 23,
    title: "Ensino",
    type: 'content',
    content: [
      "Bíblia aplicada à vida com clareza e participação.",
      "Talk simples e fiel à Palavra.",
      "Perguntas de aplicação prática.",
      "Todos participam, não só um fala."
    ]
  },
  {
    id: 24,
    title: "Fortalecimento",
    type: 'content',
    content: [
      "Renovo espiritual e encorajamento.",
      "Oração final com seriedade.",
      "Ministração e encorajamento pela Palavra.",
      "Celebrar vitórias e avanços."
    ]
  },
  {
    id: 25,
    title: "Crescimento",
    type: 'content',
    content: [
      "Formação de discípulos e maturidade espiritual.",
      "Desenvolver rotina com Deus (Palavra e oração).",
      "Acompanhar novos convertidos e visitantes.",
      "Ativar dons e envolver no serviço."
    ]
  },
  {
    id: 26,
    title: "Multiplicação",
    type: 'content',
    content: [
      "Abrir espaço para novas vidas e proteger o cuidado.",
      "Formar líder em treinamento desde cedo.",
      "Delegar funções e preparar nova casa.",
      "Planejar quando o grupo se aproxima do limite."
    ]
  },
  {
    id: 27,
    title: "Líderes e Anfitriões",
    type: 'capa',
    subtitle: "O coração do serviço nas casas.",
  },
  {
    id: 28,
    title: "Líder do MOVE",
    type: 'checklist',
    subtitle: "Responsabilidades",
    checklist: [
      { id: 'lr1', text: "guardar a visão e o clima espiritual" },
      { id: 'lr2', text: "conduzir talk com clareza e Bíblia aberta" },
      { id: 'lr3', text: "acompanhar pessoas durante a semana" },
      { id: 'lr4', text: "corrigir com amor e verdade" },
      { id: 'lr5', text: "delegar funções e formar novos líderes" }
    ],
    callout: "O que se espera: ser servo, firme, presente, intencional e ensinável."
  },
  {
    id: 29,
    title: "Anfitrião",
    type: 'checklist',
    subtitle: "Responsabilidades",
    checklist: [
      { id: 'ar1', text: "abrir a casa e gerar ambiente acolhedor" },
      { id: 'ar2', text: "apoiar organização e pontualidade" },
      { id: 'ar3', text: "ajudar a receber pessoas com alegria" },
      { id: 'ar4', text: "orientar e ter zelo pela casa (limpeza e ordem)" }
    ],
    callout: "Postura: hospitalidade com honra e discrição."
  },
  {
    id: 30,
    title: "Líder em treinamento",
    type: 'checklist',
    checklist: [
      { id: 'lt1', text: "servir com constância e humildade" },
      { id: 'lt2', text: "aprender observando e praticando" },
      { id: 'lt3', text: "conduzir partes do encontro sob orientação" },
      { id: 'lt4', text: "responsabilidade crescente e iniciativa" }
    ]
  },
  {
    id: 31,
    title: "MOVE na prática",
    type: 'content',
    subtitle: "Princípios do encontro",
    content: [
      "pontualidade é honra (líder nunca atrasa)",
      "simplicidade com excelência",
      "todos participam",
      "tempo respeitado para proteger a casa",
      "cadeiras em círculo"
    ]
  },
  {
    id: 32,
    title: "Roteiro Sugerido (60 a 75 min)",
    type: 'checklist',
    checklist: [
      { id: 'rot1', text: "Recepção e conexão (10 min)" },
      { id: 'rot2', text: "Oração inicial ou louvor (5 a 10 min)" },
      { id: 'rot3', text: "Palavra do dia (Talk) (15 min)" },
      { id: 'rot4', text: "Aplicação e participação (20 a 25 min)" },
      { id: 'rot5', text: "Oração, ministração e pedidos (10 a 15 min)" },
      { id: 'rot6', text: "Tempo de mesa (comunhão)" }
    ],
    callout: "Jamais estender além do combinado. Respeite o tempo de todos."
  },
  {
    id: 33,
    title: "Acompanhamento Semanal",
    type: 'content',
    content: [
      "O MOVE não vive só no dia do encontro. Ele vive no acompanhamento.",
      "contato com quem faltou (com amor)",
      "oração por necessidades específicas",
      "atenção a novos convertidos",
      "grupo para comunicação"
    ],
    callout: "VOCÊ NÃO É UM LÍDER DE REUNIÃO. VOCÊ É UM PASTOR DE PESSOAS."
  },
  {
    id: 34,
    title: "Saúde do MOVE",
    type: 'reflection',
    question: "A verdadeira medida de saúde do MOVE não é só casa cheia. É vida acompanhada.",
  },
  {
    id: 35,
    title: "Confidencialidade",
    type: 'content',
    content: [
      "vulnerabilidade tratada com honra",
      "não expomos pessoas",
      "não fofocamos",
      "não julgamos histórias",
      "verdade e amor caminham juntos"
    ]
  },
  {
    id: 36,
    title: "Crescimento e multiplicação",
    type: 'content',
    content: [
      "Multiplicação não é dividir amigos. É proteger o cuidado e abrir espaço.",
      "quando o grupo está entre 20 a 30 pessoas, começa o preparo.",
      "a multiplicação acontece com paz, alinhamento e propósito."
    ]
  },
  {
    id: 37,
    title: "Comunicação e Honra",
    type: 'checklist',
    checklist: [
      { id: 'com1', text: "evite excesso de conteúdos aleatórios no WhatsApp" },
      { id: 'com2', text: "evite polêmicas" },
      { id: 'com3', text: "assuntos sensíveis: tratar no privado" },
      { id: 'com4', text: "celebre novas vidas e avanços" }
    ]
  },
  {
    id: 38,
    title: "Finalização",
    type: 'capa',
    subtitle: "Bom é isso!\nVamos juntos até o final. Ninguém fica para trás.",
  }
];
