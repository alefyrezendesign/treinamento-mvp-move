
import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, Settings, X, Activity } from 'lucide-react';

interface LandingScreenProps {
  onStart: () => void;
  headline: string;
  isEditMode: boolean;
  onToggleEdit: () => void;
}

const ScramblingLetter: React.FC<{ char: string; isExiting: boolean; index: number }> = ({ char, isExiting, index }) => {
  const [displayChar, setDisplayChar] = useState(char);

  useEffect(() => {
    if (!isExiting) {
      setDisplayChar(char);
      return;
    }

    const startDelay = Math.random() * 500;
    
    const timeout = setTimeout(() => {
      const interval = setInterval(() => {
        setDisplayChar(Math.floor(Math.random() * 10).toString());
      }, 50 + Math.random() * 50);

      return () => clearInterval(interval);
    }, startDelay);

    return () => clearTimeout(timeout);
  }, [isExiting, char]);

  const variants = {
    exit: {
      opacity: 0,
      y: (Math.random() - 0.5) * 150,
      x: (Math.random() - 0.5) * 50,
      filter: ["blur(0px)", "blur(8px)", "blur(25px)"],
      scaleY: [1, 2, 0.5, 0],
      transition: { 
        duration: 1.2, 
        delay: index * 0.05 + Math.random() * 0.4,
        ease: "easeInOut"
      }
    }
  };

  return (
    <motion.span
      variants={variants}
      animate={isExiting ? "exit" : ""}
      className="inline-block"
    >
      {displayChar === " " ? "\u00A0" : displayChar}
    </motion.span>
  );
};

const LandingScreen: React.FC<LandingScreenProps> = ({ onStart, headline, isEditMode, onToggleEdit }) => {
  const [showConfig, setShowConfig] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);
  const [isExiting, setIsExiting] = useState(false);

  const handleAuth = () => {
    if (password === '1234') {
      onToggleEdit();
      setShowConfig(false);
      setPassword('');
      setError(false);
    } else {
      setError(true);
      setTimeout(() => setError(false), 2000);
    }
  };

  const handleStartTransition = () => {
    setIsExiting(true);
    setTimeout(() => {
      onStart();
    }, 2000);
  };

  const chars = useMemo(() => headline.split(""), [headline]);

  return (
    <motion.div 
      className="absolute inset-0 flex flex-col items-center justify-center p-6 z-50 bg-[#000000] overflow-hidden"
    >
      {/* Background Orbe */}
      <div className="absolute inset-0 pointer-events-none">
        <motion.div 
          animate={isExiting ? { opacity: 0 } : { 
            scale: [1, 1.1, 1],
            opacity: [0.05, 0.1, 0.05]
          }}
          transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120vw] h-[120vw] rounded-full blur-[150px]"
          style={{
            background: 'radial-gradient(circle, #2e1065 0%, transparent 70%)'
          }}
        />
      </div>

      {/* Content centered */}
      <div className="flex flex-col items-center text-center relative z-10 w-full max-w-4xl">
        {/* Church Name Label */}
        <motion.div 
          animate={isExiting ? { opacity: 0, y: -20 } : { opacity: 1, y: 0 }}
          className="flex items-center gap-3 px-6 py-2 rounded-full bg-white/[0.02] border border-white/5 backdrop-blur-md mb-8"
        >
          <Activity size={12} className="text-purple-600 animate-pulse" />
          <span className="text-[10px] md:text-[12px] font-black tracking-[0.5em] uppercase text-zinc-400">Ministério Visão e Propósito</span>
        </motion.div>

        {/* MOVE Headline */}
        <div className="flex select-none overflow-visible mb-6 justify-center">
          {chars.map((char, i) => (
            <div key={`head-${i}`} className="text-[clamp(6rem,28vw,22rem)] font-display text-white leading-[0.75] tracking-tighter">
              <ScramblingLetter char={char} isExiting={isExiting} index={i} />
            </div>
          ))}
        </div>

        {/* Access Button */}
        <motion.button
          animate={isExiting ? { opacity: 0, scale: 0.9, y: 10 } : { 
            scale: [1, 1.02, 1],
          }}
          transition={{ duration: 0.4 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleStartTransition}
          className="mt-8 group relative flex items-center gap-6 bg-[#120626] text-purple-200 border border-purple-500/20 px-14 py-7 rounded-[2rem] font-black text-xl md:text-2xl hover:text-white transition-all shadow-[0_20px_60px_rgba(88,28,135,0.15)] font-ui uppercase tracking-[0.2em] backdrop-blur-xl overflow-hidden"
        >
          Acessar Treinamento
          <ArrowRight className="group-hover:translate-x-2 transition-transform" size={28} />
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:animate-[shimmer_2s_infinite] pointer-events-none" />
        </motion.button>
      </div>

      {/* Hidden Admin Trigger */}
      <button onClick={() => setShowConfig(true)} className="fixed bottom-6 right-6 p-3 text-zinc-900 hover:text-purple-900 transition-all opacity-10 hover:opacity-100 z-50">
        <Settings size={18} />
      </button>

      <AnimatePresence>
        {showConfig && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/95 backdrop-blur-3xl"
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-full max-w-xs bg-zinc-950 border border-white/5 p-8 rounded-[2.5rem] shadow-2xl"
            >
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-[9px] font-black uppercase tracking-[0.4em] text-zinc-600">Acesso Restrito</h3>
                <button onClick={() => setShowConfig(false)} className="text-zinc-800 hover:text-white"><X size={18} /></button>
              </div>
              <input 
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAuth()}
                placeholder="••••"
                className={`w-full bg-black border ${error ? 'border-red-900' : 'border-white/5'} rounded-xl py-4 px-6 text-white text-center text-xl focus:outline-none focus:border-purple-900/40 transition-all mb-6 font-display`}
                autoFocus
              />
              <button onClick={handleAuth} className="w-full py-4 rounded-xl bg-purple-900/20 border border-purple-500/20 text-purple-400 font-bold text-[10px] uppercase tracking-widest hover:bg-purple-900/40 transition-all">
                Entrar
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`
        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
      `}</style>
    </motion.div>
  );
};

export default LandingScreen;
