
import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, HelpCircle, Quote, Sparkles, ArrowRight, Dna } from 'lucide-react';
import { Slide } from '../types';

interface SlideContentProps {
  slide: Slide;
  completedItems: Set<string>;
  onToggleCheck: (id: string) => void;
  isEditMode: boolean;
  onUpdate: (updatedSlide: Slide) => void;
  currentIndex: number;
}

const SlideContent: React.FC<SlideContentProps> = ({ slide, completedItems, onToggleCheck, isEditMode, onUpdate, currentIndex }) => {
  
  const handleTextChange = (field: keyof Slide | 'contentItem' | 'checkItem', value: string, index?: number) => {
    if (field === 'title') onUpdate({ ...slide, title: value });
    if (field === 'subtitle') onUpdate({ ...slide, subtitle: value });
    if (field === 'question') onUpdate({ ...slide, question: value });
    if (field === 'callout') onUpdate({ ...slide, callout: value });
    if (field === 'contentItem' && typeof index === 'number') {
      const newContent = [...(slide.content || [])];
      newContent[index] = value;
      onUpdate({ ...slide, content: newContent });
    }
    if (field === 'checkItem' && typeof index === 'number') {
      const newCheck = [...(slide.checklist || [])];
      newCheck[index].text = value;
      onUpdate({ ...slide, checklist: newCheck });
    }
  };

  const containerVariants = {
    show: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] } }
  };

  // DESIGN CAPA (Impacto Máximo)
  if (slide.type === 'capa' && !isEditMode) {
    const isDnaSlide = slide.title.includes("DNA");

    return (
      <div className="relative flex flex-col items-start justify-center min-h-[60vh] w-full">
        {/* Número da página gigante no fundo */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 font-display text-[45vh] leading-none text-white opacity-[0.015] select-none pointer-events-none hidden lg:block">
          {String(currentIndex + 1).padStart(2, '0')}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="relative z-10 w-full"
        >
          {isDnaSlide && (
            <motion.div 
              animate={{ 
                scale: [1, 1.1, 1],
                opacity: [0.5, 1, 0.5]
              }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="mb-8 text-purple-600"
            >
              <Dna size={80} className="lg:w-32 lg:h-32" strokeWidth={1.5} />
            </motion.div>
          )}

          <h2 className="text-[clamp(4rem,15vw,12rem)] lg:text-[18vh] font-display leading-[0.75] text-white uppercase tracking-tighter mb-4">
            {slide.title}
          </h2>
          
          {slide.subtitle && (
            <div className="max-w-4xl">
               <h3 className="text-[clamp(1.5rem,5vw,4rem)] lg:text-[6vh] font-display leading-[0.9] text-white uppercase tracking-tight opacity-90">
                {slide.subtitle.split('\n').map((line, i) => (
                  <span key={i} className="block">
                    {line.split(/(Servir com Excelência)/g).map((part, j) => 
                      part === "Servir com Excelência" ? (
                        <span key={j} className="text-purple-600 shadow-purple-600/20">{part}</span>
                      ) : part
                    )}
                  </span>
                ))}
              </h3>
            </div>
          )}

          {slide.expandableContent && (
            <div className="mt-20 flex flex-col md:flex-row items-start md:items-center gap-6 lg:gap-10">
              <div className="w-16 h-1 lg:w-24 lg:h-[3px] bg-purple-600 shadow-[0_0_20px_rgba(147,51,234,0.6)]" />
              <div className="flex flex-col">
                {slide.expandableContent.split('\n').map((line, i) => (
                  <p key={i} className={`text-zinc-400 font-medium tracking-tight ${i === 0 ? 'text-xl lg:text-2xl text-zinc-300' : 'text-sm lg:text-lg'}`}>
                    {line}
                  </p>
                ))}
              </div>
            </div>
          )}
        </motion.div>
      </div>
    );
  }

  return (
    <div className="relative w-full flex flex-col h-full justify-center py-6 lg:py-0">
      {/* Background Page Number Sutil */}
      <div className="absolute -left-16 top-0 font-display text-[22vh] leading-none text-white opacity-[0.008] select-none pointer-events-none hidden lg:block">
        {String(currentIndex + 1).padStart(2, '0')}
      </div>

      <header className="mb-12 lg:mb-16 relative z-10">
        <div className="flex items-center gap-4 mb-5">
           <div className="w-8 h-[2px] bg-purple-600" />
           <span className="text-[9px] font-black uppercase tracking-[0.6em] text-zinc-500 font-ui">MOVE</span>
        </div>
        <div className="relative">
          <h2 className="text-[clamp(2.5rem,8vw,5.5rem)] lg:text-[8.5vh] font-display leading-[0.9] text-white uppercase tracking-tighter">
            {slide.title}
          </h2>
        </div>

        {slide.subtitle && (
          <div className="mt-6 flex gap-6 items-start">
            <div className="w-[2px] h-10 bg-zinc-800" />
            <p className="text-lg lg:text-[2.6vh] text-zinc-500 font-bold tracking-tight uppercase max-w-4xl">
              {slide.subtitle}
            </p>
          </div>
        )}
      </header>

      <motion.div 
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 items-start relative z-10"
      >
        <div className="lg:col-span-7 xl:col-span-7 space-y-12">
          {slide.content && (
            <div className="space-y-12">
              {slide.content.map((point, i) => {
                const isFirst = i === 0;
                return (
                  <motion.div 
                    key={i} 
                    variants={itemVariants}
                    className={`${isFirst ? 'relative' : 'pl-4 lg:pl-10 border-l border-white/5'}`}
                  >
                    {isFirst && (
                      <div className="absolute -left-10 top-2 hidden lg:block">
                        <ArrowRight size={24} className="text-purple-600 opacity-50" />
                      </div>
                    )}
                    
                    {isEditMode ? (
                      <textarea 
                        value={point}
                        onChange={(e) => handleTextChange('contentItem', e.target.value, i)}
                        className="bg-transparent w-full text-white text-xl outline-none"
                      />
                    ) : (
                      <p className={`
                        ${isFirst 
                          ? 'text-[clamp(1.5rem,4vw,2.5rem)] lg:text-[3.8vh] leading-[1.1] text-white font-display uppercase tracking-tight' 
                          : 'text-lg lg:text-[2.6vh] text-zinc-400 leading-relaxed font-medium'}
                      `}>
                         {point.split(/(Servir com Excelência)/g).map((part, k) => 
                          part === "Servir com Excelência" ? (
                            <span key={k} className="text-purple-600 font-black">{part}</span>
                          ) : part
                        )}
                      </p>
                    )}
                  </motion.div>
                );
              })}
            </div>
          )}

          {slide.checklist && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {slide.checklist.map((item, idx) => (
                <motion.div 
                  key={item.id} 
                  variants={itemVariants}
                  className="group flex items-center gap-5 p-7 rounded-[2.5rem] bg-white/[0.02] border border-white/[0.04] hover:bg-white/[0.05] transition-all hover:border-purple-600/30"
                >
                  <div className="shrink-0 w-12 h-12 rounded-2xl bg-purple-900/10 flex items-center justify-center border border-purple-500/10 group-hover:scale-110 transition-transform">
                    <CheckCircle className="text-purple-500" size={24} />
                  </div>
                  <span className="text-lg lg:text-[2.2vh] font-bold font-display text-zinc-200 uppercase tracking-tight leading-tight">
                    {item.text}
                  </span>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {(slide.callout || slide.question || isEditMode) && (
          <div className="lg:col-span-5 xl:col-span-5 space-y-8 lg:pt-4">
            {(slide.callout || isEditMode) && (
              <motion.div 
                variants={itemVariants}
                className="p-10 lg:p-14 bg-purple-700 rounded-[3.5rem] shadow-[0_40px_100px_rgba(88,28,135,0.3)] relative overflow-hidden group"
              >
                <div className="absolute -right-10 -bottom-10 opacity-10 rotate-12 group-hover:scale-110 transition-transform duration-1000">
                   <Quote size={200} />
                </div>
                <div className="flex items-center gap-3 mb-10">
                   <Sparkles size={16} className="text-purple-200" />
                   <h4 className="text-white/40 text-[10px] font-black uppercase tracking-[0.4em]">NOTA DE LIDERANÇA</h4>
                </div>
                <p className="text-white font-display text-2xl lg:text-[3.5vh] leading-[1] uppercase italic tracking-tighter relative z-10">
                  {slide.callout}
                </p>
              </motion.div>
            )}

            {(slide.question || isEditMode) && (
              <motion.div 
                variants={itemVariants}
                className="p-10 lg:p-14 bg-[#0a0a0a] rounded-[3.5rem] border border-white/5 shadow-2xl relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-purple-600/5 blur-[60px] rounded-full" />
                <div className="w-14 h-14 rounded-2xl bg-zinc-900 flex items-center justify-center mb-10 border border-white/5">
                   <HelpCircle className="text-purple-500" size={28} />
                </div>
                <h4 className="text-zinc-600 font-bold uppercase tracking-[0.3em] text-[9px] mb-6">MOMENTO DE CONEXÃO</h4>
                <p className="text-white text-2xl lg:text-[3.8vh] font-display leading-[1.05] uppercase tracking-tighter">
                  "{slide.question}"
                </p>
              </motion.div>
            )}
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default SlideContent;
